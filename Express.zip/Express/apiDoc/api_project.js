define({
  "name": "ToDo App",
  "version": "0.0.2",
  "description": "API Document for ToDo App",
  "title": "ToDo App APIs",
  "url": "https://localhost:3000",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-05-15T16:11:04.345Z",
    "url": "http://apidocjs.com",
    "version": "0.22.1"
  }
});
